package edu.boisestate.cs410.charity.web;

import com.mitchellbosecke.pebble.loader.ClasspathLoader;
import org.apache.commons.dbcp2.PoolingDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import spark.*;
import spark.template.pebble.PebbleTemplateEngine;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * Server for the charity database.
 */
public class CharityServer {
    private static final Logger logger = LoggerFactory.getLogger(CharityServer.class);

    private final PoolingDataSource<? extends Connection> pool;
    private final Service http;
    private final TemplateEngine engine;

    public CharityServer(PoolingDataSource<? extends Connection> pds, Service svc) {
        pool = pds;
        http = svc;
        engine = new PebbleTemplateEngine(new ClasspathLoader());

        http.get("/", this::rootPage, engine);
        http.get("/years/:year", this::yearPage, engine);
        http.get("/donors/:donor/:year", this::donorReport, engine);
    }

    ModelAndView rootPage(Request request, Response response) throws SQLException {
        Map<String,Object> fields = new HashMap<>();
        List<Map<String,Object>> years = new ArrayList<>();
        try (Connection cxn = pool.getConnection()) {
            /* do things with the database */

            try(Statement stmt = cxn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT EXTRACT(YEAR FROM gift_date) as gift_year,COUNT(gift_id)AS gift_count " +
                                                    "FROM gift " +
                                                    "GROUP BY gift_year " +
                                                    "ORDER BY gift_year DESC")){
                while(rs.next()){
                    Map<String, Object> year = new HashMap<>();
                    year.put("year_date", rs.getInt("gift_year"));
                    year.put("count", rs.getInt("gift_count"));
                    years.add(year);
                }
                fields.put("years", years);
            }

        }

        return new ModelAndView(fields, "base.html");
    }

    ModelAndView yearPage(Request request, Response response) throws SQLException{
        int year = Integer.parseInt(request.params("year"));

        Map<String,Object> fields = new HashMap<>();
        fields.put("year",year);

        List<Map<String,Object>> donors = new ArrayList<>();
        try (Connection cxn = pool.getConnection()) {
            try(PreparedStatement pstmt = cxn.prepareStatement("SELECT gift.donor_id AS dID, donor.donor_name AS dName, COUNT(gift_id) AS gift_count " +
                    "FROM gift " +
                    "JOIN donor USING (donor_id) " +
                    "WHERE EXTRACT(YEAR FROM gift_date)=? " +
                    "GROUP BY gift.donor_id, donor.donor_name " +
                    "ORDER BY dName " )){
                pstmt.setInt(1,year);
                try(ResultSet rs = pstmt.executeQuery()){
                    while(rs.next()){
                        Map<String, Object> donor = new HashMap<>();
                        donor.put("donorID", rs.getString("dID"));
                        donor.put("donorName", rs.getString("dName"));
                        donor.put("gCount", rs.getInt("gift_count"));
                        donors.add(donor);
                    }
                    fields.put("donors", donors);
                }
            }

        }
        return new ModelAndView(fields, "year.html");
    }

    ModelAndView donorReport(Request request, Response response) throws SQLException {
        int donorId = Integer.parseInt(request.params("donor"));
        int year = Integer.parseInt(request.params("year"));

        Map<String,Object> fields = new HashMap<>();
        fields.put("donor", donorId);
        fields.put("year", year);

        try(Connection cxn = pool.getConnection()) {
            //Get Donor info
            try(PreparedStatement pstmt = cxn.prepareStatement("SELECT donor_name, donor_address, donor_city, donor_state, donor_zip " +
                    "FROM donor " +
                    "WHERE (donor_id = ?)")){
                pstmt.setInt(1, donorId);
                try(ResultSet rs = pstmt.executeQuery()){
                    if(!rs.next()){
                        throw new IllegalStateException("NO SUCH DONOR?");
                    }
                    fields.put("name", rs.getString("donor_name"));
                    fields.put("address", rs.getString("donor_address"));
                    fields.put("city", rs.getString("donor_city"));
                    fields.put("state", rs.getString("donor_state"));
                    fields.put("zip", rs.getString("donor_zip"));
                }
            }

            //Grab donor's gift info
            List<Map<String,Object>> gifts = new ArrayList<>();
            try(PreparedStatement pstmt = cxn.prepareStatement("SELECT gift_date, fund_name, amount " +
                    "FROM gift " +
                    "  JOIN gift_fund_allocation USING(gift_id) " +
                    "  JOIN fund USING (fund_id) " +
                    "  WHERE (donor_id = ? AND EXTRACT(YEAR FROM gift_date) = ?) " +
                    "  GROUP BY gift_date, fund_name, amount")){
                    pstmt.setInt(1, donorId);
                    pstmt.setInt(2,year);
                    int total = 0;
                    try(ResultSet rs = pstmt.executeQuery()) {
                        while (rs.next()) {
                            Map<String, Object> gift = new HashMap<>();
                            gift.put("name", rs.getString("fund_name"));
                            gift.put("amount", rs.getInt("amount"));
                            gift.put("date", rs.getString("gift_date"));
                            total += rs.getInt("amount");
                            gifts.add(gift);
                        }
                        fields.put("total", total);
                        fields.put("gifts", gifts);
                    }
            }

            //Grab info by fund
            List<Map<String,Object>> funds = new ArrayList<>();
            try(PreparedStatement pstmt = cxn.prepareStatement("SELECT fund_name, SUM(amount) AS amount " +
                    "FROM gift\n" +
                    "  JOIN gift_fund_allocation ON(gift.gift_id = gift_fund_allocation.gift_id) " +
                    "  JOIN fund USING (fund_id) " +
                    "WHERE (donor_id = ? AND EXTRACT(YEAR FROM gift_date) = ? AND fund.fund_id = gift_fund_allocation.fund_id ) " +
                    "GROUP BY fund_name")){
                pstmt.setInt(1, donorId);
                pstmt.setInt(2,year);
                try(ResultSet rs = pstmt.executeQuery()){
                    while(rs.next()){
                        Map<String, Object> fund = new HashMap<>();
                        fund.put("name",rs.getString("fund_name"));
                        fund.put("amount", rs.getInt("amount"));
                        funds.add(fund);
                    }
                    fields.put("funds", funds);
                }
            }

        }
        return new ModelAndView(fields, "donor.html");
    }
}
